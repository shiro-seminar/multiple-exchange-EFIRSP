from __future__ import annotations
import torch

from .config import Config
from .bundles import BundleIndex
from .data_gen import sample_types, types_to_bundle_utils, outside_option_utils
from .model import BundleNet
from .losses import expected_utilities_from_probs, sp_loss_sampled
from .oracle import oracle_welfare_no_disposal


@torch.no_grad()
def ir_feasible_oracle(bidx: BundleIndex, U_true: torch.Tensor, outside: torch.Tensor) -> torch.Tensor:
    device = U_true.device
    comp = bidx.complement_index().to(device=device)  # [K]
    U1 = U_true[:, 0, :]                             # [B,K]
    U2c = U_true[:, 1, :][:, comp]                   # [B,K]  k indexes agent1 bundle
    welfare = U1 + U2c                               # [B,K]

    feas = (U1 >= outside[:, 0:1]) & (U2c >= outside[:, 1:2])
    neg_inf = torch.full_like(welfare, -1e18)
    welfare_feas = torch.where(feas, welfare, neg_inf)

    best = welfare_feas.max(dim=1).values
    fallback = outside.sum(dim=1)
    best = torch.where(best < -1e17, fallback, best)
    return best


def one_hot_from_argmax(probs_shape, chosen: torch.Tensor) -> torch.Tensor:
    probs_det = torch.zeros(probs_shape, device=chosen.device)
    probs_det.scatter_(1, chosen.view(-1, 1), 1.0)
    return probs_det


def main():
    device = torch.device("cpu")

    ckpt = torch.load("bundle_net.pt", map_location=device)

    cfg = Config()
    if isinstance(ckpt, dict) and "cfg" in ckpt and isinstance(ckpt["cfg"], dict):
        for k, v in ckpt["cfg"].items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
    cfg.device = "cpu"

    bidx = BundleIndex(num_items=cfg.num_items)
    net = BundleNet(cfg, bidx).to(device=device)
    net.load_state_dict(ckpt["state_dict"])
    net.eval()

    N = 10000
    batch = sample_types(cfg, bidx, N)
    v_true = batch["v_true"]
    a_true = batch["alpha_true"]
    endow_mask1 = batch["endow_mask1"]

    U_true = types_to_bundle_utils(cfg, bidx, v_true, a_true)
    outside = outside_option_utils(cfg, bidx, U_true, endow_mask1)

    welfare_sq = outside.sum(dim=1).mean().item()

    K = bidx.num_bundles
    probs_uni = torch.full((N, K), 1.0 / K, device=device)
    EU_uni = expected_utilities_from_probs(bidx, probs_uni, U_true)
    welfare_uni = EU_uni.sum(dim=1).mean().item()
    ir_uni = torch.relu(outside - EU_uni).mean().item()

    welfare_oracle = oracle_welfare_no_disposal(bidx, U_true).mean().item()
    welfare_ir_oracle = ir_feasible_oracle(bidx, U_true, outside).mean().item()

    probs = net(v_true, a_true)
    EU = expected_utilities_from_probs(bidx, probs, U_true)
    welfare_lot = EU.sum(dim=1).mean().item()
    ir_lot = torch.relu(outside - EU).mean().item()

    chosen = net.predict_argmax(v_true, a_true)
    probs_det = one_hot_from_argmax(probs.shape, chosen)
    EU_det = expected_utilities_from_probs(bidx, probs_det, U_true)
    welfare_det = EU_det.sum(dim=1).mean().item()
    ir_det = torch.relu(outside - EU_det).mean().item()

    zeros = (chosen == 0).float().mean().item()
    uniq = int(torch.unique(chosen).numel())

    # SP approximation on smaller subset for speed
    cfg_sp = cfg
    cfg_sp.misreport_samples = min(cfg_sp.misreport_samples, 16)
    n_sp = 2000
    v_sp = v_true[:n_sp]
    a_sp = a_true[:n_sp]
    U_sp = U_true[:n_sp]
    endow_sp = endow_mask1[:n_sp]

    sp_lot = sp_loss_sampled(cfg_sp, bidx, net, v_sp, a_sp, U_sp, endow_sp).item()

    class NetDet:
        def __call__(self, v_report, a_report):
            ch = net.predict_argmax(v_report, a_report)
            probs0 = torch.zeros((v_report.shape[0], K), device=v_report.device)
            probs0.scatter_(1, ch.view(-1, 1), 1.0)
            return probs0

    sp_det = sp_loss_sampled(cfg_sp, bidx, NetDet(), v_sp, a_sp, U_sp, endow_sp).item()

    print("")
    print("=== Comparison (N=10000 test types; SP approx on 2000) ===")
    print(f"Status quo (endowment) welfare:              {welfare_sq:.4f}   (IR=0 by definition)")
    print(f"Uniform random lottery welfare:              {welfare_uni:.4f}   IR_violation={ir_uni:.4f}")
    print(f"Oracle (no constraints) welfare upper bound: {welfare_oracle:.4f}")
    print(f"Oracle with IR-feasibility upper bound:      {welfare_ir_oracle:.4f}")
    print("")
    print(f"Learned (lottery) welfare:                   {welfare_lot:.4f}   IR_violation={ir_lot:.4f}   SP≈{sp_lot:.4f}")
    print(f"Learned (argmax deterministic) welfare:      {welfare_det:.4f}   IR_violation={ir_det:.4f}   SP≈{sp_det:.4f}")
    print("")
    print(f"Argmax bundle stats: P(bundle=0)={zeros:.4f}, unique_bundles={uniq}")


if __name__ == "__main__":
    main()
