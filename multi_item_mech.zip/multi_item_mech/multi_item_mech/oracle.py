from __future__ import annotations
import torch
from .bundles import BundleIndex

@torch.no_grad()
def oracle_welfare_no_disposal(bidx: BundleIndex, U_true: torch.Tensor) -> torch.Tensor:
    """Compute first-best welfare by enumerating all 2^m bundles (no IR constraint).

    U_true: [B,2,K] utilities for each agent for each bundle mask (as received by that agent).
    Agent 2 receives complement.
    Returns:
      best_welfare: [B]
    """
    device = U_true.device
    comp = bidx.complement_index().to(device=device)  # [K]
    U1 = U_true[:, 0, :]                             # [B,K]
    U2c = U_true[:, 1, :][:, comp]                   # [B,K] where k indexes agent1 bundle
    welfare = U1 + U2c                               # [B,K]
    best = welfare.max(dim=1).values
    return best
