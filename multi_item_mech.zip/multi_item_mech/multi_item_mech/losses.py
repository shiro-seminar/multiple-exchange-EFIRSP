from __future__ import annotations
import torch
from .bundles import BundleIndex
from .config import Config
from .data_gen import types_to_bundle_utils, outside_option_utils

def expected_utilities_from_probs(bidx: BundleIndex, probs: torch.Tensor, U_true: torch.Tensor) -> torch.Tensor:
    """Compute EU for each agent under lottery over agent1 bundles.

    probs: [B,K] where K=2^m, distribution over agent1 bundle masks.
    U_true: [B,2,K] utilities for each agent for each bundle mask (as received by that agent).
            Agent 2 receives complement bundle, so we index complement.
    Returns:
      EU: [B,2]
    """
    device = probs.device
    comp = bidx.complement_index().to(device=device)  # [K]
    EU1 = torch.sum(probs * U_true[:, 0, :], dim=1)
    EU2 = torch.sum(probs * U_true[:, 1, :][:, comp], dim=1)
    return torch.stack([EU1, EU2], dim=1)

def ef_loss(bidx: BundleIndex, probs: torch.Tensor, U_true: torch.Tensor) -> torch.Tensor:
    EU = expected_utilities_from_probs(bidx, probs, U_true)
    welfare = EU.sum(dim=1).mean()
    return -welfare  # maximize welfare

def ir_loss(cfg: Config, bidx: BundleIndex, probs: torch.Tensor, U_true: torch.Tensor, endow_mask1: torch.Tensor) -> torch.Tensor:
    EU = expected_utilities_from_probs(bidx, probs, U_true)  # [B,2]
    outside = outside_option_utils(cfg, bidx, U_true, endow_mask1)  # [B,2]
    viol = torch.relu(outside - EU)  # [B,2]
    return viol.mean()

def sample_misreports(cfg: Config, v_true: torch.Tensor, alpha_true: torch.Tensor, num_samples: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Generate misreports by noisy perturbations + clipping to allowed ranges."""
    device = v_true.device
    B, A, m = v_true.shape
    # noise
    v_noise = torch.randn((B, num_samples, m), device=device) * cfg.misreport_noise_v
    a_noise = torch.randn((B, num_samples), device=device) * cfg.misreport_noise_alpha
    return v_noise, a_noise

def sp_loss_sampled(
    cfg: Config,
    bidx: BundleIndex,
    net,
    v_true: torch.Tensor,
    alpha_true: torch.Tensor,
    U_true: torch.Tensor,
    endow_mask1: torch.Tensor,
) -> torch.Tensor:
    """Approximate dominant-strategy regret by sampling misreports.

    Mechanism takes (reported types) -> probs -> expected utility under TRUE preferences.
    For each agent i, we sample M misreports for (v_i, alpha_i), hold others fixed truthful,
    and compute max positive gain.
    """
    device = v_true.device
    B, A, m = v_true.shape
    assert A == 2, "This scaffold assumes 2 agents."
    M = cfg.misreport_samples

    # EU under truthful reports
    probs_true = net(v_true, alpha_true)
    EU_true = expected_utilities_from_probs(bidx, probs_true, U_true)  # [B,2]

    regrets = []
    for i in range(2):
        v_noise, a_noise = sample_misreports(cfg, v_true, alpha_true, M)  # [B,M,m], [B,M]
        v_mis_i = torch.clamp(v_true[:, i, :].unsqueeze(1) + v_noise, cfg.v_min, cfg.v_max)  # [B,M,m]
        a_mis_i = torch.clamp(alpha_true[:, i].unsqueeze(1) + a_noise, cfg.alpha_min, cfg.alpha_max)  # [B,M]

        # Build reported tensors for all misreports in a vectorized way
        v_rep = v_true.unsqueeze(1).repeat(1, M, 1, 1)          # [B,M,2,m]
        a_rep = alpha_true.unsqueeze(1).repeat(1, M, 1)         # [B,M,2]
        v_rep[:, :, i, :] = v_mis_i
        a_rep[:, :, i] = a_mis_i

        v_rep_f = v_rep.reshape(B * M, 2, m)
        a_rep_f = a_rep.reshape(B * M, 2)

        probs_mis = net(v_rep_f, a_rep_f).reshape(B, M, -1)     # [B,M,K]
        # Utilities computed under TRUE preferences; only allocation changes.
        EU_mis_i = expected_utilities_from_probs(bidx, probs_mis.reshape(B*M, -1), U_true.repeat_interleave(M, dim=0))
        EU_mis_i = EU_mis_i.reshape(B, M, 2)[:, :, i]           # [B,M]

        gain = EU_mis_i - EU_true[:, i].unsqueeze(1)            # [B,M]
        regret = torch.relu(gain).max(dim=1).values             # [B]
        regrets.append(regret)

    sp = torch.stack(regrets, dim=1).mean()
    return sp

def augmented_loss(cfg: Config, ef: torch.Tensor, ir: torch.Tensor, sp: torch.Tensor) -> torch.Tensor:
    # simple augmented Lagrangian style
    return ef + cfg.lambda_ir * ir + cfg.lambda_sp * sp + cfg.rho * (ir * ir + sp * sp)
