from dataclasses import dataclass

@dataclass
class Config:
    # Problem
    num_agents: int = 2
    num_items: int = 5
    # Utility model
    v_min: float = 0.0
    v_max: float = 1.0
    alpha_min: float = 0.0      # set <0 later to allow substitutes
    alpha_max: float = 0.5
    # Endowment / outside option
    random_endowment: bool = True  # endowment is a random bundle for agent 1; agent 2 gets complement
    # Model
    hidden: int = 128
    depth: int = 3
    dropout: float = 0.0
    # Training
    batch_size: int = 512
    steps: int = 5000
    lr: float = 3e-4
    grad_clip: float = 1.0
    seed: int = 0

    # Loss weights (Augmented Lagrangian style, simple version)
    lambda_ir: float = 10.0
    lambda_sp: float = 10.0
    rho: float = 10.0

    # SP approximation
    misreport_samples: int = 16
    misreport_noise_v: float = 0.35
    misreport_noise_alpha: float = 0.35

    # Softmax temperature
    temperature: float = 1.0

    # Device
    device: str = "cpu"
