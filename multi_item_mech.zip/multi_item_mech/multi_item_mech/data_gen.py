from __future__ import annotations
import torch
from .bundles import BundleIndex
from .config import Config

def sample_types(cfg: Config, bidx: BundleIndex, batch_size: int) -> dict:
    """Sample true types and (optionally) endowments.

    Returns dict with:
      v_true: [B,2,m]
      alpha_true: [B,2]
      endow_mask1: [B]  (agent 1 endowment bundle as bitmask)  agent2 gets complement
    """
    device = torch.device(cfg.device)
    B, A, m = batch_size, cfg.num_agents, cfg.num_items
    assert A == 2, "This scaffold currently assumes 2 agents."

    v_true = torch.empty((B, A, m), device=device).uniform_(cfg.v_min, cfg.v_max)
    alpha_true = torch.empty((B, A), device=device).uniform_(cfg.alpha_min, cfg.alpha_max)

    if cfg.random_endowment:
        endow_mask1 = torch.randint(low=0, high=bidx.num_bundles, size=(B,), device=device)
    else:
        endow_mask1 = torch.zeros((B,), dtype=torch.long, device=device)

    return {
        "v_true": v_true,
        "alpha_true": alpha_true,
        "endow_mask1": endow_mask1,
    }

def types_to_bundle_utils(cfg: Config, bidx: BundleIndex, v: torch.Tensor, alpha: torch.Tensor) -> torch.Tensor:
    """Compute utilities for every bundle mask.

    Args:
      v: [B,2,m]
      alpha: [B,2]
    Returns:
      U: [B,2,2^m], where U[:,i,k] = u_i(bundle mask k)
    Utility:
      u_i(S) = sum_{g in S} v_{i,g} + (|S|-1) * alpha_i   if |S|>=1 else 0
    """
    device = v.device
    masks = bidx.masks_tensor().to(device=device)         # [K,m]
    K = masks.shape[0]

    # additive part: sum v_{i,g} * 1[g in S]
    # v: [B,2,m], masks: [K,m] -> [B,2,K]
    add = torch.einsum("bim,km->bik", v, masks)

    # bundle size
    size = masks.sum(dim=1)                               # [K]
    size = size.view(1, 1, K)                             # [1,1,K]

    # synergy: (|S|-1)*alpha if |S|>=1 else 0
    alpha_ = alpha.unsqueeze(-1)                          # [B,2,1]
    syn = torch.where(size >= 1.0, (size - 1.0) * alpha_, torch.zeros_like(add))

    return add + syn

def outside_option_utils(cfg: Config, bidx: BundleIndex, U_true: torch.Tensor, endow_mask1: torch.Tensor) -> torch.Tensor:
    """Outside option utility for each agent given endowment allocation.

    endow_mask1: [B] is agent1 endowment; agent2 gets complement.
    Returns:
      outside: [B,2]
    """
    device = U_true.device
    comp = bidx.complement_index().to(device=device)  # [K]
    endow1 = endow_mask1.long()
    endow2 = comp[endow1]
    u1 = U_true[:, 0, :].gather(1, endow1.view(-1, 1)).squeeze(1)
    u2 = U_true[:, 1, :].gather(1, endow2.view(-1, 1)).squeeze(1)
    return torch.stack([u1, u2], dim=1)
