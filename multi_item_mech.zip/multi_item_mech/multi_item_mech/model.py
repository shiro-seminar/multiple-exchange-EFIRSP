from __future__ import annotations
import torch
import torch.nn as nn
from .config import Config
from .bundles import BundleIndex

class BundleNet(nn.Module):
    """A minimal MLP mechanism: (reported types) -> distribution over 32 bundles for agent 1."""
    def __init__(self, cfg: Config, bidx: BundleIndex):
        super().__init__()
        self.cfg = cfg
        self.bidx = bidx
        in_dim = cfg.num_agents * cfg.num_items + cfg.num_agents  # v (2*5) + alpha (2) = 12
        layers = []
        h = cfg.hidden
        d = cfg.depth
        for i in range(d):
            layers.append(nn.Linear(in_dim if i == 0 else h, h))
            layers.append(nn.ReLU())
            if cfg.dropout > 0:
                layers.append(nn.Dropout(cfg.dropout))
        layers.append(nn.Linear(h, bidx.num_bundles))  # logits for each bundle mask
        self.net = nn.Sequential(*layers)

    def forward(self, v_report: torch.Tensor, alpha_report: torch.Tensor, temperature: float | None = None) -> torch.Tensor:
        """Returns probs over bundles for agent 1. Shape: [B, 2^m]."""
        if temperature is None:
            temperature = self.cfg.temperature
        x = torch.cat([v_report.reshape(v_report.shape[0], -1), alpha_report.reshape(alpha_report.shape[0], -1)], dim=1)
        logits = self.net(x) / max(temperature, 1e-6)
        probs = torch.softmax(logits, dim=-1)
        return probs

    @torch.no_grad()
    def predict_argmax(self, v_report: torch.Tensor, alpha_report: torch.Tensor) -> torch.Tensor:
        """Deterministic allocation: returns chosen bundle mask index for agent 1. Shape: [B]."""
        x = torch.cat([v_report.reshape(v_report.shape[0], -1), alpha_report.reshape(alpha_report.shape[0], -1)], dim=1)
        logits = self.net(x)
        return torch.argmax(logits, dim=-1)
