from __future__ import annotations
import math
import torch
import torch.nn as nn
from .config import Config
from .bundles import BundleIndex
from .data_gen import sample_types, types_to_bundle_utils
from .model import BundleNet
from .losses import ef_loss, ir_loss, sp_loss_sampled, augmented_loss
from .oracle import oracle_welfare_no_disposal

def main():
    cfg = Config()
    torch.manual_seed(cfg.seed)

    bidx = BundleIndex(num_items=cfg.num_items)
    device = torch.device(cfg.device)

    net = BundleNet(cfg, bidx).to(device=device)
    opt = torch.optim.Adam(net.parameters(), lr=cfg.lr)

    for step in range(1, cfg.steps + 1):
        batch = sample_types(cfg, bidx, cfg.batch_size)
        v_true = batch["v_true"]
        a_true = batch["alpha_true"]
        endow_mask1 = batch["endow_mask1"]

        # True utilities over bundles
        U_true = types_to_bundle_utils(cfg, bidx, v_true, a_true)

        # Mechanism outcome under truthful reports
        probs = net(v_true, a_true)

        ef = ef_loss(bidx, probs, U_true)
        ir = ir_loss(cfg, bidx, probs, U_true, endow_mask1)
        sp = sp_loss_sampled(cfg, bidx, net, v_true, a_true, U_true, endow_mask1)

        loss = augmented_loss(cfg, ef, ir, sp)

        opt.zero_grad(set_to_none=True)
        loss.backward()
        if cfg.grad_clip is not None and cfg.grad_clip > 0:
            nn.utils.clip_grad_norm_(net.parameters(), cfg.grad_clip)
        opt.step()

        if step % 200 == 0 or step == 1:
            with torch.no_grad():
                # Compare to oracle (first-best) welfare as a reference
                EU_welfare = -(ef.detach())  # because ef = -mean welfare
                oracle = oracle_welfare_no_disposal(bidx, U_true).mean()
                gap = oracle - EU_welfare
            print(f"step={step:5d} loss={loss.item():.4f}  welfare={EU_welfare.item():.4f}  oracle={oracle.item():.4f}  gap={gap.item():.4f}  IR={ir.item():.4f}  SP={sp.item():.4f}")

    # save
    path = "bundle_net.pt"
    torch.save({"state_dict": net.state_dict(), "cfg": cfg.__dict__}, path)
    print(f"Saved model to {path}")

if __name__ == "__main__":
    main()
